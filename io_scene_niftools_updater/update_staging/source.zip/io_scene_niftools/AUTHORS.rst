Current developers
------------------

* neomonkeus
* Hendrix


Former developers
-----------------

* Amorilia
* Brandano
* Ghostwalker71
* m4444x

Contributors
------------

* Aaron1178
* Alphax
* Arcimaestro
* Arthmoor
* Artorp
* Candoran2
* Deedes
* Eli2
* Entim
* Eugenius-v
* Fritz_fretz
* GandaG
* Hanaisse
* Kikaimegami
* Lhammonds
* malo
* mgm101
* opusGlass
* Pacificmorrowind
* Pentinen
* shon
* Tamira
* Thedaywalker
* Tijer
* zin
